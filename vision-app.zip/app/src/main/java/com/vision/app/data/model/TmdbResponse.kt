package com.vision.app.data.model

import com.google.gson.annotations.SerializedName

data class TmdbMovieResponse(
    @SerializedName("page") val page: Int,
    @SerializedName("results") val results: List<TmdbMovieDto>
)

data class TmdbMovieDto(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?, // For TV series
    @SerializedName("overview") val overview: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?
) {
    fun toMediaItem(isTvSeries: Boolean = false): MediaItem {
        val baseUrl = "https://image.tmdb.org/t/p/w500"
        val backdropBase = "https://image.tmdb.org/t/p/w780"
        return MediaItem(
            id = id.toString(),
            title = title ?: name ?: "Unknown Title",
            description = overview ?: "No overview available.",
            posterUrl = posterPath?.let { "$baseUrl$it" },
            backdropUrl = backdropPath?.let { "$backdropBase$it" },
            rating = voteAverage ?: 0.0,
            releaseDate = releaseDate ?: firstAirDate,
            type = if (isTvSeries) MediaType.SERIES else MediaType.MOVIE,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" // Demo stream fallback
        )
    }
}
