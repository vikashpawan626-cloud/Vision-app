package com.vision.app.data.model

import java.io.Serializable

enum class MediaType {
    MOVIE,
    SERIES,
    ANIME,
    PODCAST
}

data class MediaItem(
    val id: String,
    val title: String,
    val description: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val rating: Double,
    val releaseDate: String?,
    val type: MediaType,
    val streamUrl: String? = null // Video stream URL (HLS/MP4) or Podcast audio RSS URL
) : Serializable
