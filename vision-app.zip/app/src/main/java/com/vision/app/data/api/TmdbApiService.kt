package com.vision.app.data.api

import com.vision.app.data.model.TmdbMovieResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface TmdbApiService {
    // Trending Hollywood & Global Movies
    @GET("trending/movie/day")
    suspend fun getTrendingMovies(
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): TmdbMovieResponse

    // Bollywood / Hindi Movies (region=IN, with_original_language=hi)
    @GET("discover/movie")
    suspend fun getBollywoodMovies(
        @Query("api_key") apiKey: String,
        @Query("with_original_language") language: String = "hi",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1
    ): TmdbMovieResponse

    // Trending TV Series (World & Local)
    @GET("trending/tv/day")
    suspend fun getTrendingSeries(
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): TmdbMovieResponse

    // Search across movies & series
    @GET("search/multi")
    suspend fun searchMulti(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("page") page: Int = 1
    ): TmdbMovieResponse
}
