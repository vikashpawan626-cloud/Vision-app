package com.vision.app.data.api

import com.vision.app.data.model.JikanAnimeResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface JikanApiService {
    // Top Anime of all time & popular current anime
    @GET("top/anime")
    suspend fun getTopAnime(
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 25
    ): JikanAnimeResponse

    // Search anime
    @GET("anime")
    suspend fun searchAnime(
        @Query("q") query: String,
        @Query("limit") limit: Int = 25
    ): JikanAnimeResponse
}
