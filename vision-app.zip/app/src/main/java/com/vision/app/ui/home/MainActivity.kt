package com.vision.app.ui.home

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.vision.app.R
import com.vision.app.data.repository.MediaRepository
import com.vision.app.databinding.ActivityMainBinding
import com.vision.app.ui.detail.DetailActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val repository = MediaRepository()
    private lateinit var adapter: MediaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupCategoryChips()

        // Default load Hollywood Trending
        loadHollywood()
    }

    private fun setupRecyclerView() {
        adapter = MediaAdapter(emptyList()) { selectedItem ->
            DetailActivity.start(this, selectedItem)
        }
        binding.rvMedia.layoutManager = GridLayoutManager(this, 2)
        binding.rvMedia.adapter = adapter
    }

    private fun setupCategoryChips() {
        binding.chipHollywood.setOnClickListener { loadHollywood() }
        binding.chipBollywood.setOnClickListener { loadBollywood() }
        binding.chipSeries.setOnClickListener { loadSeries() }
        binding.chipAnime.setOnClickListener { loadAnime() }
        binding.chipPodcasts.setOnClickListener { loadPodcasts() }
    }

    private fun loadHollywood() {
        showLoading(true)
        lifecycleScope.launch {
            val result = repository.getHollywoodMovies()
            showLoading(false)
            result.onSuccess { adapter.updateData(it) }
                .onFailure { showError(it.message) }
        }
    }

    private fun loadBollywood() {
        showLoading(true)
        lifecycleScope.launch {
            val result = repository.getBollywoodMovies()
            showLoading(false)
            result.onSuccess { adapter.updateData(it) }
                .onFailure { showError(it.message) }
        }
    }

    private fun loadSeries() {
        showLoading(true)
        lifecycleScope.launch {
            val result = repository.getSeries()
            showLoading(false)
            result.onSuccess { adapter.updateData(it) }
                .onFailure { showError(it.message) }
        }
    }

    private fun loadAnime() {
        showLoading(true)
        lifecycleScope.launch {
            val result = repository.getAnime()
            showLoading(false)
            result.onSuccess { adapter.updateData(it) }
                .onFailure { showError(it.message) }
        }
    }

    private fun loadPodcasts() {
        showLoading(true)
        lifecycleScope.launch {
            val result = repository.getPodcasts()
            showLoading(false)
            result.onSuccess { adapter.updateData(it) }
                .onFailure { showError(it.message) }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showError(message: String?) {
        Toast.makeText(
            this,
            message ?: getString(R.string.error_loading),
            Toast.LENGTH_SHORT
        ).show()
    }
}
