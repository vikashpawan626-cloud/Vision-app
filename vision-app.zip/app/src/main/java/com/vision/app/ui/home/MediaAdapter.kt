package com.vision.app.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.vision.app.R
import com.vision.app.data.model.MediaItem
import com.vision.app.databinding.ItemMediaCardBinding

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<MediaAdapter.MediaViewHolder>() {

    inner class MediaViewHolder(private val binding: ItemMediaCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: MediaItem) {
            binding.tvTitle.text = item.title
            binding.tvRating.text = String.format("★ %.1f", item.rating)
            binding.tvCategory.text = "${item.type.name} • ${item.releaseDate ?: ""}"

            binding.ivPoster.load(item.posterUrl) {
                crossfade(true)
                placeholder(R.color.surface_dark)
                error(R.color.surface_dark)
            }

            binding.root.setOnClickListener {
                onItemClick(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        val binding = ItemMediaCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MediaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<MediaItem>) {
        this.items = newItems
        notifyDataSetChanged()
    }
}
