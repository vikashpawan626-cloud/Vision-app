package com.vision.app.data.model

import com.google.gson.annotations.SerializedName

data class JikanAnimeResponse(
    @SerializedName("data") val data: List<JikanAnimeDto>
)

data class JikanAnimeDto(
    @SerializedName("mal_id") val malId: Int,
    @SerializedName("title") val title: String,
    @SerializedName("synopsis") val synopsis: String?,
    @SerializedName("score") val score: Double?,
    @SerializedName("images") val images: JikanImages?,
    @SerializedName("trailer") val trailer: JikanTrailer?
) {
    fun toMediaItem(): MediaItem {
        return MediaItem(
            id = malId.toString(),
            title = title,
            description = synopsis ?: "No synopsis available.",
            posterUrl = images?.jpg?.largeImageUrl ?: images?.jpg?.imageUrl,
            backdropUrl = images?.jpg?.largeImageUrl,
            rating = score ?: 0.0,
            releaseDate = "Anime",
            type = MediaType.ANIME,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
        )
    }
}

data class JikanImages(
    @SerializedName("jpg") val jpg: JikanImageUrls?
)

data class JikanImageUrls(
    @SerializedName("image_url") val imageUrl: String?,
    @SerializedName("large_image_url") val largeImageUrl: String?
)

data class JikanTrailer(
    @SerializedName("youtube_id") val youtubeId: String?,
    @SerializedName("url") val url: String?,
    @SerializedName("embed_url") val embedUrl: String?
)
