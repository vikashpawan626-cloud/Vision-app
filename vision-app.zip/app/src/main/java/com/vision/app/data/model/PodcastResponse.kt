package com.vision.app.data.model

import com.google.gson.annotations.SerializedName

data class PodcastSearchResponse(
    @SerializedName("resultCount") val resultCount: Int,
    @SerializedName("results") val results: List<PodcastItemDto>
)

data class PodcastItemDto(
    @SerializedName("trackId") val trackId: Long,
    @SerializedName("trackName") val trackName: String?,
    @SerializedName("collectionName") val collectionName: String?,
    @SerializedName("artistName") val artistName: String?,
    @SerializedName("artworkUrl600") val artworkUrl600: String?,
    @SerializedName("artworkUrl100") val artworkUrl100: String?,
    @SerializedName("feedUrl") val feedUrl: String?,
    @SerializedName("primaryGenreName") val primaryGenreName: String?
) {
    fun toMediaItem(): MediaItem {
        return MediaItem(
            id = trackId.toString(),
            title = trackName ?: collectionName ?: "Untitled Podcast",
            description = "Host: ${artistName ?: "Unknown"} • Genre: ${primaryGenreName ?: "Podcast"}",
            posterUrl = artworkUrl600 ?: artworkUrl100,
            backdropUrl = artworkUrl600 ?: artworkUrl100,
            rating = 5.0,
            releaseDate = "Podcast",
            type = MediaType.PODCAST,
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" // Sample audio stream
        )
    }
}
