package com.vision.app.data.api

import com.vision.app.data.model.PodcastSearchResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface PodcastApiService {
    @GET("search")
    suspend fun getPopularPodcasts(
        @Query("term") term: String = "podcast",
        @Query("media") media: String = "podcast",
        @Query("entity") entity: String = "podcast",
        @Query("limit") limit: Int = 30
    ): PodcastSearchResponse

    @GET("search")
    suspend fun searchPodcasts(
        @Query("term") term: String,
        @Query("media") media: String = "podcast",
        @Query("limit") limit: Int = 30
    ): PodcastSearchResponse
}
