package com.vision.app.ui.detail

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.vision.app.R
import com.vision.app.data.model.MediaItem
import com.vision.app.databinding.ActivityDetailBinding
import com.vision.app.ui.player.PlayerActivity

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    companion object {
        private const val EXTRA_MEDIA_ITEM = "extra_media_item"

        fun start(context: Context, mediaItem: MediaItem) {
            val intent = Intent(context, DetailActivity::class.java).apply {
                putExtra(EXTRA_MEDIA_ITEM, mediaItem)
            }
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mediaItem = intent.getSerializableExtra(EXTRA_MEDIA_ITEM) as? MediaItem
        if (mediaItem == null) {
            finish()
            return
        }

        bindData(mediaItem)
    }

    private fun bindData(item: MediaItem) {
        binding.tvDetailTitle.text = item.title
        binding.tvDetailRating.text = String.format("★ %.1f", item.rating)
        binding.tvDetailMeta.text = "${item.type.name} • ${item.releaseDate ?: "N/A"}"
        binding.tvDetailOverview.text = item.description

        binding.ivDetailBackdrop.load(item.backdropUrl ?: item.posterUrl) {
            crossfade(true)
            placeholder(R.color.surface_dark)
            error(R.color.surface_dark)
        }

        binding.btnPlay.setOnClickListener {
            val streamUrl = item.streamUrl
            if (!streamUrl.isNullOrEmpty()) {
                PlayerActivity.start(this, streamUrl, item.title)
            } else {
                Toast.makeText(this, "Stream URL not available", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
