# Vision - All-in-One Entertainment App

Vision is a modern Android application built in Kotlin that aggregates:
1. **Hollywood Movies & Global Releases** (TMDB API)
2. **Bollywood & Indian Regional Movies** (TMDB Bollywood Filter)
3. **Web Series & TV Shows** (TMDB TV API)
4. **Anime Series & Movies** (Jikan / MyAnimeList API - No key required)
5. **Podcasts Worldwide** (Apple iTunes Podcast API - Free playable audio streams)

---

## Architecture & Tech Stack
- **Language:** Kotlin
- **Architecture:** MVVM (Model-View-ViewModel) + Repository Pattern
- **Networking:** Retrofit 2 + OkHttp3 + Coroutines
- **Image Caching & Loading:** Coil
- **Media Player Engine:** AndroidX Media3 (ExoPlayer) with HLS (`.m3u8`) and MP4 streaming support
- **UI:** Material Design 3 Dark Cinema Theme

---

## Setup & Running in Android Studio

1. **Android Studio me project open karein:**
   - File -> Open -> Select `vision-app` folder.

2. **TMDB API Key add karein:**
   - `https://www.themoviedb.org/` par free account banayein.
   - Settings -> API -> Generate API Key.
   - File open karein:
     `app/src/main/java/com/vision/app/data/repository/MediaRepository.kt`
   - `tmdbApiKey` variable me apni key paste karein:
     ```kotlin
     private val tmdbApiKey = "YOUR_ACTUAL_TMDB_API_KEY"
     ```

3. **Build & Generate APK:**
   - Android Studio me **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)** click karein.
   - APK compile hokar `app/build/outputs/apk/debug/app-debug.apk` me save ho jayegi.
   - Apne phone me install karke test karein!
