package com.vision.app.data.repository

import com.vision.app.data.api.RetrofitClient
import com.vision.app.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository {

    // Aap apni free TMDB API key yahan daal sakte hain (https://www.themoviedb.org/settings/api)
    private val tmdbApiKey = "YOUR_TMDB_API_KEY_HERE"

    suspend fun getHollywoodMovies(): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.tmdbApi.getTrendingMovies(tmdbApiKey)
            val items = response.results.map { it.toMediaItem(isTvSeries = false) }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getBollywoodMovies(): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.tmdbApi.getBollywoodMovies(tmdbApiKey)
            val items = response.results.map { it.toMediaItem(isTvSeries = false) }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSeries(): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.tmdbApi.getTrendingSeries(tmdbApiKey)
            val items = response.results.map { it.toMediaItem(isTvSeries = true) }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAnime(): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.jikanApi.getTopAnime()
            val items = response.data.map { it.toMediaItem() }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPodcasts(): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        try {
            val response = RetrofitClient.podcastApi.getPopularPodcasts()
            val items = response.results.map { it.toMediaItem() }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
